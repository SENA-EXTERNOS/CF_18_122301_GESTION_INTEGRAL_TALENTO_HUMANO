function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Vy36ZiY9zP":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

