function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5l4BOwfG4ID":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

